with open('input.txt', 'r') as f_in, open('fizzbuzz.txt', 'w') as f_out:
    for line in f_in:
        fizz, buzz, n = map(int, line.split(","))
        for i in range(1, n+1):
            output = ""
            if i % fizz == 0:
                output += "F"
            if i % buzz == 0:
                output += "B"
            if output == "":
                output = str(i)
            f_out.write(output + " ")
        f_out.write("\n")

